module Case where

import Tip 


f [] = True
f x = True

prop_f a = f a === True 
